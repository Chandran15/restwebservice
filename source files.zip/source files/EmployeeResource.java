package com.cts.web.controller;



import java.net.URI;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import com.cts.web.bean.Employee;


@Path("/employee")
public class EmployeeResource {

	@Context UriInfo uriInfo;
	
	static HashMap<String, Employee> employeeMap = new HashMap<String, Employee>();
	
	static {
		employeeMap.put("370941", new Employee("Sandeep", "370941", 9999));
		employeeMap.put("371124", new Employee("Aayush", "371124", 8000));
		employeeMap.put("281125", new Employee("Sameer", "281125", 7000));
	}
	
	  @GET
	    @Produces(MediaType.TEXT_PLAIN)
	    public String getIt() {
	        return "Hello, Employee Resource";
	    }
	  
	@GET
	@Produces({"application/xml,application/json"})
	public Employee getEmployee() {
		Employee employee = new Employee("Sandeep", "370941", 9999);
		return employee;
	}

	@GET
	@Path("/{employeeId}")
	@Produces({ MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee getEmployeeById(@PathParam("employeeId") String employeeId) {
		Employee employee = employeeMap.get(employeeId);
		if (employee==null) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
		return employee;
	}
	



	@GET
	@Path("/all")
	@Produces("application/json")
	public Response getEmployees() throws Exception {
		 Set<String> employeeKeySet=employeeMap.keySet();
		for (String employeeKey:employeeKeySet) {
			Employee employeeRecord=employeeMap.get(employeeKey);
			employeeRecord.setLink(returnHATEOSLink(employeeRecord));
		}
		return Response.status(200).entity(employeeMap).build();
	}

	@POST
	@Path("/addEmployee")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response addEmployee(Employee employee) throws Exception{
		employeeMap.put(employee.getEmployeeId(), employee);
		System.out.println("Employee is successfully added"+employeeMap.toString());
		return getEmployees();
	}
	
	@DELETE
	@Path("/deleteEmployee")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response deleteEmployee(Employee employee) throws Exception{
		System.out.println(" Removed Employee "+employee);
		employeeMap.remove(employee.getEmployeeId());
		System.out.println("Employee is successfully removed"+employeeMap.toString());
		return getEmployees();
	}
	
	@PUT
	@Path("/updateEmployee")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response putEmployee(Employee employee) throws Exception{
		System.out.println(" Updated  Employee "+employee);
		employeeMap.put(employee.getEmployeeId(), employee);
		System.out.println("Employee is successfully Updated"+employeeMap.toString());
		return getEmployees();
	}
	
	
	public String returnHATEOSLink(Employee employee) throws Exception{
		UriBuilder ub = uriInfo.getBaseUriBuilder();
		ub.path("employee");
		URI userUri = ub.path(employee.getEmployeeId()).build();
		return userUri.toURL().toString();
	}
	
}
